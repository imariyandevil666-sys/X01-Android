# X01 Android

پروژه Android Studio برای اپ X01.

## ساخت APK
1. Android Studio را نصب کن.
2. این پوشه را در Android Studio باز کن.
3. صبر کن Gradle Sync تمام شود.
4. از منوی:
   Build → Build APK(s)
5. APK در مسیر `app/build/outputs/apk/debug/` ساخته می‌شود.

## نصب مستقیم
بعد از Build، فایل APK را به گوشی منتقل کن و نصب کن.

## نکته
این پروژه رابط X01 را داخل یک Android WebView اجرا می‌کند و مجوز اینترنت و میکروفن دارد.
برای اتصال به سرور واقعی، مقدار `SERVER_URL` در `app/src/main/assets/index.html` را به دامنه HTTPS سرور X01 تغییر بده.

این پروژه به‌تنهایی SMS/OTP یا سرور آنلاین واقعی ایجاد نمی‌کند؛ برای آن باید backend قبلی X01 روی یک سرور اینترنتی deploy شود.
