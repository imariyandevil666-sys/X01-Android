# ساخت APK بدون Android Studio

این پروژه برای GitHub Actions آماده شده است.

## روش پیشنهادی

1. یک repository جدید در GitHub بساز.
2. فایل‌های این پروژه را داخل repository آپلود کن.
3. فایل workflow در مسیر زیر قرار دارد:
   `.github/workflows/build-apk.yml`
4. در GitHub وارد بخش **Actions** شو.
5. Workflow با نام **Build X01 APK** را انتخاب کن.
6. گزینه **Run workflow** را بزن.
7. بعد از پایان Build، در صفحه اجرای Workflow بخش **Artifacts** را باز کن.
8. فایل `X01-debug-apk.zip` را دانلود و از حالت ZIP خارج کن.
9. فایل `app-debug.apk` را روی گوشی نصب کن.

## نکته مهم اتصال آنلاین

این Build فقط APK را می‌سازد. برای بازی آنلاین باید backend X01 نیز روی یک سرور اینترنتی deploy شود.

بعد از داشتن آدرس سرور، در:
`app/src/main/assets/index.html`

این خط را تغییر بده:

`const SERVER_URL="";`

مثلاً:

`const SERVER_URL="https://api.example.com";`

برای نسخه نهایی بهتر است APK با سرور HTTPS/WSS، احراز هویت، دیتابیس، TURN برای ویس و سیستم امنیتی/ضدتقلب ساخته شود.

## وضعیت فعلی

- Android APK build: آماده
- رابط X01: آماده
- بیلیارد: آماده به‌عنوان MVP
- WebSocket: آماده در backend قبلی
- چت: آماده
- WebRTC voice signaling: پایه آماده
- SMS/OTP واقعی: هنوز نیازمند سرویس SMS و backend
- انتشار عمومی: نیازمند سرور و تنظیمات production
